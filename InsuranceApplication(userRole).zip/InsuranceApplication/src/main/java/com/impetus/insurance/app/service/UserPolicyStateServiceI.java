package com.impetus.insurance.app.service;

import java.util.List;

import com.impetus.insurance.app.entity.*;

/**
 * This interface implements UserPolicyStateService Interface, it declares the
 * methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface UserPolicyStateServiceI {

	/**
	 * This method adds new insurance request object.
	 * 
	 * @param object
	 */
	public void add(UserPolicyStateDto object);

	/**
	 * This method returns all the polices that are purchased by the user with the
	 * given userId
	 * 
	 * @param userId
	 * @return List of purchased insurance policies
	 */
	public List<UserPolicyState> getMyPolicies(int userId);

	/**
	 * This method returns all the insurance request objects with the given status
	 * 
	 * @param status
	 * @return List of insurance request objects
	 */
	public List<UserPolicyState> getRequestObjectByStatus(String status);

	/**
	 * This method returns all the existing insurance request objects
	 * 
	 * @return List of insurance request objects
	 */
	public List<UserPolicyState> getAll();

	/**
	 * This method returns the insurance request object with the given id
	 * 
	 * @param id
	 * @return UserPolicyState object
	 */
	public UserPolicyState viewById(int id);

	/**
	 * This method updates the insurance request object with the given id and
	 * returns updated object
	 * 
	 * @param id
	 * @param object
	 * @return UserPolicyState object
	 */
	public UserPolicyState update(int id, UserPolicyState object);

}
