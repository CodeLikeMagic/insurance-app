package com.impetus.insurance.app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.service.PolicyServiceI;

@Component
public class PolicyService implements PolicyServiceI {

	@Autowired
	PolicyRepository policyRepo;

	@Override
	public List<Policy> viewAll() {
		// TODO Auto-generated method stub
		List<Policy> policyList = (List<Policy>) policyRepo.findAll();
		return policyList;
	}

	@Override
	public Policy viewById(int id) throws InvalidPolicyIdException {
		// TODO Auto-generated method stub
		Optional<Policy> pObject = Optional.ofNullable(
				policyRepo.findById(id).orElseThrow(() -> new InvalidPolicyIdException("Invalid policy id")));

		Policy object = null;
		if (pObject.isPresent()) {
			object = pObject.get();
		}
		return object;
	}

	@Override
	public void add(Policy object) {
		// TODO Auto-generated method stub
		policyRepo.save(object);
	}

	@Override
	public void remove(int policyId) throws InvalidPolicyIdException {
		// TODO Auto-generated method stub
		if (policyRepo.findById(policyId).isEmpty()) {
			throw new InvalidPolicyIdException("Invalid policy id");
		}
		policyRepo.deleteById(policyId);
	}

	@Override
	public void edit(int id, Policy object) throws InvalidPolicyIdException {
		// TODO Auto-generated method stub
		if (viewById(id).getId() == id) {
			policyRepo.save(object);
		}
	}

}
