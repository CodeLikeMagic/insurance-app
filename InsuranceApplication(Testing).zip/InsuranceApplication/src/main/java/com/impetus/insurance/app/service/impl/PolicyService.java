package com.impetus.insurance.app.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.service.PolicyServiceI;

@Component
public class PolicyService implements PolicyServiceI {

	@Autowired
	PolicyRepository policyRepo;

	@Autowired
	UserPolicyStateRepository uspRepo;

	@Override
	public List<Policy> viewAll() {
		return (List<Policy>) policyRepo.findAll();
	}

	@Override
	public void add(Policy object) {
		policyRepo.save(object);
	}

	@Override
	public void remove(int policyId) throws InvalidPolicyIdException {
		if (!uspRepo.findAllByPolicyId(policyId).isEmpty()) {
			throw new InvalidPolicyIdException("Invalid policy id");
		}
		policyRepo.deleteById(policyId);
	}

	@Override
	public void edit(int id, Policy object) throws InvalidPolicyIdException {
		if (viewById(id).getId() == id) {
			policyRepo.save(object);
		}
	}

	@Override
	public Policy viewById(int id) throws InvalidPolicyIdException {
		Optional<Policy> pObject = Optional.ofNullable(
				policyRepo.findById(id).orElseThrow(() -> new InvalidPolicyIdException("Invalid policy id")));

		Policy object = null;
		if (pObject.isPresent()) {
			object = pObject.get();
		}
		return object;
	}

}
