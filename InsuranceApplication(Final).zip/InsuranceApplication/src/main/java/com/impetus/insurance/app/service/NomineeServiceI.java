package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.Nominee;

public interface NomineeServiceI {

	public Nominee add(Nominee object);

	public void remove(int id);

	public Nominee findByAadhar(long aNo);
}
