package com.impetus.insurance.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserPolicyStateServiceI;

@Component
public class UserPolicyStateService implements UserPolicyStateServiceI{

	public static final String APPROVED = "APPROVED"; 
	public static final String PENDING = "PENDING";
	public static final String REJECTED = "REJECTED";
	public static final String AWAITING = "AWAITING";
	
	@Autowired
	UserPolicyStateRepository uspRepo;
	
	@Autowired
	PolicyRepository policyRepo;
	
	@Autowired
	NomineeRepository nomineeRepo;
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	ModelMapper mapper;

	@Scheduled(initialDelay = 1000000, fixedDelay = 1000000)
	public void autoApproval() {
		
		
		List<UserPolicyState> listOfRequests = (List<UserPolicyState>) uspRepo.findAll();
		//uspRepo.findAllByStatus(PENDING);
		List<UserPolicyState> listOfPendingRequests = listOfRequests.stream().filter(x -> (x.getStatus().equals(PENDING))).collect(Collectors.toList()); 
		List<UserPolicyState> BatchOfUpdateRequests = new ArrayList<>();
		
		
		System.out.println("size of " + listOfPendingRequests.size());
		
		for(UserPolicyState request : listOfPendingRequests)
		{
			boolean approveFlag = false;
			Optional<User> fetchedObj = userRepo.findById(request.getOwner().getId()); 
			User obj = fetchedObj.get();
			int age = obj.getAge();
			
			long finalPremium = request.getPremium();
			long income = Long.valueOf(obj.getIncome());
			
			//underage
			if(age < 18)
			{
				System.out.println("age");
				request.setStatus(AWAITING);
				System.out.println(request.toString());
				approveFlag = true;
			}
			
			
			//based on income, final premium and mode of pay
			String summary = request.getSummary();
			int payFor = fetchCoverFor(summary);
			System.out.println("payFor = " + payFor + "\n ");
			int div1, div2, div3;
			div1 = StringUtils.indexOf(summary, "Monthly");
			div2 = StringUtils.indexOf(summary, "One-time");
			div3 = StringUtils.indexOf(summary, "Yearly");
			
			if(div1 > 0)
			{
				if((income/12) < finalPremium)
				{
					System.out.println("/12");
					request.setStatus(AWAITING);

					System.out.println(request.toString());
					approveFlag = true;
				}
			}
			if(div2 > 0|| div3 > 0)
			{
				System.out.println("div2, div3");
				if((income) < finalPremium)
				{
					request.setStatus(AWAITING);
					approveFlag = true;
				}
			}
			
			//
			if(age + 20 < payFor)
			{
				System.out.println("age+20 less");
				request.setStatus(AWAITING);
				approveFlag = true;
			}
			
			//all conditions passed request is approved 
			if(approveFlag == false)
			{
				System.out.println("aprroved");
				request.setStatus(APPROVED);
				
				System.out.println(request.toString());

			}
			
			BatchOfUpdateRequests.add(request);
			
		}
		System.out.println("update & size =" + BatchOfUpdateRequests.size());
		for(UserPolicyState x : BatchOfUpdateRequests)
		{
			System.out.println(x.toString());
			update(x.getId(), x);
		}
		System.out.println("update\n\n");
		
		List<UserPolicyState> listOfRs = (List<UserPolicyState>) uspRepo.findAll();
		
		for(UserPolicyState x : listOfRs)
		{
			System.out.println(x.toString());
		}
	}
	
	public int fetchCoverFor(String summary) {
		String s = "";
	    int cnt = 0 ;
	    
	   for(int i=0 ; i<summary.length() ; i++)
	   {
	       if(cnt == 2)
	       {
	           if(s.length() <= 2 && summary.charAt(i) != 'y')
    	           {
    	           	Boolean flag = Character.isDigit(summary.charAt(i));
                        if(flag) 
                        {
                            s += summary.charAt(i) ;
                        }
    	           }
    	           else
    	           {
    	               break ;
    	           }
	       }
	       else if(summary.charAt(i) == ':')
	       {
	           cnt++ ;
	       }
	   }
	   
	   int coverFor = Integer.parseInt(s);
	   return coverFor;
	}
	
	@Override
	public void add(UserPolicyStateDto object) {
		// TODO Auto-generated method stub
		System.out.println(object.toString());
		UserPolicyState uspObject = new UserPolicyState();
		
		uspObject.setNominee(nomineeRepo.findById(object.getNominee()));
		uspObject.setOwner(userRepo.findById(object.getOwner()));
		uspObject.setPolicy(policyRepo.findById(object.getPolicy()));
		uspObject.setPremium(object.getPremium());
		uspObject.setSummary(object.getSummary());
		
		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		
		uspObject.setTs(ts);
		uspObject.setStatus(PENDING);
		
		//UserPolicyState uspObject = mapper.map(object, UserPolicyState.class);
		//uspObject.setPolicy(object.getPolicy());
		/*Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		uspObject.setTs(ts);
		uspObject.setStatus("PENDING");*/
		System.out.println(uspObject.toString());
		uspRepo.save(uspObject);
	}

	public UserPolicyState viewById(int id){
		// TODO Auto-generated method stub
		Optional<UserPolicyState> pObject = Optional.ofNullable(uspRepo.findById(id)).get();

		UserPolicyState object = null;
		if (pObject.isPresent()) {
			object = pObject.get();
		}
		return object;
	}

	public UserPolicyState update(int id, UserPolicyState object) {
		if (viewById(id).getId() == id) {
			uspRepo.save(object);
		}
		return object;
	}
	
	public List<UserPolicyState> getMyPolicies(int userId){
		return uspRepo.findAllByOwnerId(userId);
	}
}
