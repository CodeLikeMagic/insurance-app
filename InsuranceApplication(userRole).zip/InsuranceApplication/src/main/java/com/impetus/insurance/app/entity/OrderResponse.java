package com.impetus.insurance.app.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the OrderResponse.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
public class OrderResponse {

	String secretKey;
	String razorpayOrderId;
	String applicationFee;
	String secretId;
	String pgName;

}
