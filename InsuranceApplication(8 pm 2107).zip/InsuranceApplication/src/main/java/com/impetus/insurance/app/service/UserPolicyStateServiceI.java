package com.impetus.insurance.app.service;

import java.util.List;

import com.impetus.insurance.app.entity.*;

public interface UserPolicyStateServiceI {
	public void add(UserPolicyStateDto object);
	
	public List<UserPolicyState> getMyPolicies(int userId);
	
	public List<UserPolicyState> getRequestObjectByStatus(String status);
	
	public List<UserPolicyState> getAll();
	
	public UserPolicyState viewById(int id);
	
	public UserPolicyState update(int id, UserPolicyState object);
	
}
