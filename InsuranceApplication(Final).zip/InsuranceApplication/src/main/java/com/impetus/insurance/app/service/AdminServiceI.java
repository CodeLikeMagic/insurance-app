package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface AdminServiceI {
	
	public Admin validateLogin(Admin object) throws InvalidCredentialsException;
	
	public void createNewAcccount(Admin object);
}
