package com.impetus.insurance.app.entity;

import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the UserPolicyStateDto.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
public class UserPolicyStateDto {

	/**
	 * int value for primary key
	 */
	int id;

	/**
	 * long value for premium
	 */
	long premium;

	/**
	 * int value for primary key
	 */
	int nominee;

	/**
	 * int value for primary key
	 */
	int owner;

	/**
	 * int value for primary key
	 */
	int policy;

	/**
	 * string value for summary
	 */
	String summary;

	/**
	 * Timestamp value
	 */
	Timestamp ts;

	/**
	 * string value for status
	 */
	String status;

	/**
	 * Default Constructor
	 */
	public UserPolicyStateDto() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param premium
	 * @param nominee
	 * @param owner
	 * @param policy
	 * @param summary
	 * @param ts
	 * @param status
	 */
	public UserPolicyStateDto(int id, long premium, int nominee, int owner, int policy, String summary, Timestamp ts,
			String status) {
		super();
		this.id = id;
		this.premium = premium;
		this.nominee = nominee;
		this.owner = owner;
		this.policy = policy;
		this.summary = summary;
		this.ts = ts;
		this.status = status;
	}

}
