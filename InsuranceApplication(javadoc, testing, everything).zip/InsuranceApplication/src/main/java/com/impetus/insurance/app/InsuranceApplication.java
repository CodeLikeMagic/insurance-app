package com.impetus.insurance.app;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * Date - 08/19/2022
 * This is a insurance application. Having three roles - admin, user, underwriter.
 * Requests following all the conditions get auto approved.
 * User can view , buy the policies.
 * Admin supervises all the operartions of the application 
 * Underwirter reviews the requests manually which aren't auto approved.
 * 
 * @author deeksha.patidar
 * version 1.0
 */
@SpringBootApplication
@EnableScheduling
public class InsuranceApplication {

	/**This is the main method of the application
	 * @param args arrays of string arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(InsuranceApplication.class, args);
	}

	
	/**This method handles access control check and cross origin resource sharing i.e.access control allow origin
	 * @return new cors filter
	 */
	@Bean
	CorsFilter corsFilter() {
		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

		final CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(false);
		config.setAllowedOrigins(Collections.singletonList("*"));
		config.setAllowedHeaders(Arrays.asList("Origin", "Content-Type", "Accept"));
		config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		source.registerCorsConfiguration("/**", config);
		return new CorsFilter(source);
	}
}