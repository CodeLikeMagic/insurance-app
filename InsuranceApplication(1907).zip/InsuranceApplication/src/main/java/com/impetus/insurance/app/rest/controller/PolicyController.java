package com.impetus.insurance.app.rest.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;
import com.impetus.insurance.app.service.impl.NomineeService;
import com.impetus.insurance.app.service.impl.PolicyService;

@RestController
@RequestMapping("/api/v1/")
public class PolicyController {

	@Autowired
	PolicyService policyService;

	@Autowired
	NomineeService nomineeService;

	@PostMapping("policy")
	public ResponseEntity<HttpStatus> add(@RequestBody @Valid Policy object) {
		policyService.add(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@DeleteMapping("policy/{id}")
	public void delete(@PathVariable("id") int id) throws InvalidPolicyIdException {
		policyService.remove(id);
	}

	@GetMapping("policy/{id}")
	public ResponseEntity<Policy> view(@PathVariable("id") int id) throws InvalidPolicyIdException {
		return new ResponseEntity<>(policyService.viewById(id), HttpStatus.OK);
	}

	@GetMapping("policy")
	public ResponseEntity<List<Policy>> viewAll() {
		return new ResponseEntity<>(policyService.viewAll(), HttpStatus.OK);
	}

	@PutMapping("policy/{id}")
	public ResponseEntity<HttpStatus> update(@PathVariable("id") int id, @RequestBody @Valid Policy object)
			throws InvalidPolicyIdException {
		policyService.edit(id, object);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

	@PostMapping("nominee")
	public ResponseEntity<HttpStatus> addNominee(@RequestBody Nominee object) {
		System.out.println(object.toString());
		nomineeService.add(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@DeleteMapping("nominee/{id}")
	public void deleteNominee(@PathVariable("id") int id) {
		nomineeService.remove(id);
	}
	
	@GetMapping("nominee/{aadhar_no}")
	public ResponseEntity<Nominee> getNominee(@PathVariable("aadhar_no") long aadhar_no) {
		return new ResponseEntity<>(nomineeService.findByAadhar(aadhar_no), HttpStatus.OK);
	}
}
