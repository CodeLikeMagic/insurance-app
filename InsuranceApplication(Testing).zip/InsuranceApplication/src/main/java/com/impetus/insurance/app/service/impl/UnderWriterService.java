package com.impetus.insurance.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UnderWriterRepository;
import com.impetus.insurance.app.service.UnderWriterServiceI;

@Component
public class UnderWriterService implements UnderWriterServiceI {

	@Autowired
	UnderWriterRepository underwriterRepo;

	@Override
	public UnderWriter validateLogin(UnderWriter object) throws InvalidCredentialsException {
		if (underwriterRepo.existsByEmail(object.getEmail())) // if correct email
		{
			UnderWriter obj = underwriterRepo.findByEmail(object.getEmail());
			if (object.getPassword().equals(obj.getPassword())) {
				System.out.println("success!!!");
				return object;
			} else {
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} else {
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	@Override
	public void createNewAcccount(UnderWriter object) {
		underwriterRepo.save(object);
	}

}
