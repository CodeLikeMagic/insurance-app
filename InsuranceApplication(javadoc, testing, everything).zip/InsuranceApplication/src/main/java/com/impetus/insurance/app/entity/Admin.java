package com.impetus.insurance.app.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the Admin. 
 * 
 * @author deeksha.patidar
 *
 */
@ToString
@Getter
@Setter
@Entity
@Table(name = "admin")
public class Admin {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	
	/**
	 * string value for email
	 */
	@NotNull
	String email;

	/**
	 * string value for password
	 */
	@NotNull
	String password;

	/**
	 * Default constructor
	 */
	public Admin() {

	}

	
	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param email
	 * @param password
	 */
	public Admin(int id, @NotNull String email, @NotNull String password) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
	}
}
