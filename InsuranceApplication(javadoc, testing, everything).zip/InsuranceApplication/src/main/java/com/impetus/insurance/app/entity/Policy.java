package com.impetus.insurance.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the Policy.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "policy")
public class Policy {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	/**
	 * string value for name
	 */
	@NotNull
	@Column(name = "name")
	String name;

	/**
	 * string value for description
	 */
	@NotNull
	@Column(name = "policy_provider")
	String description;

	/**
	 * int[] value for storing values of life cover amount user can take.
	 */
	@NotNull
	@Column(name = "life_cover")
	int[] lifeCover;

	/**
	 * int[] value for storing years user would like to take policy cover.
	 */
	@NotNull
	@Column(name = "cover_for")
	int[] coverFor;

	/**
	 * int[] value for storing years user would like to pay premium for.
	 */
	@NotNull
	@Column(name = "pay_for")
	int[] payFor;

	/**
	 * string value for modeOfPayment - "One-time, Monthly, Yearly"
	 */
	@NotNull
	@Column(name = "mode_of_payment")
	String[] modeOfPp;

	/**
	 * string value for typeOfPolicy - "Life, Dental"
	 */
	@NotNull
	@Column(name = "type")
	String typeOfPolicy;

	/**
	 * Default Constructor
	 */
	public Policy() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param name
	 * @param description
	 * @param lifeCover
	 * @param coverFor
	 * @param payFor
	 * @param modeOfPp
	 * @param typeOfPolicy
	 */
	public Policy(int id, @NotNull String name, @NotNull String description, @NotNull int[] lifeCover,
			@NotNull int[] coverFor, @NotNull int[] payFor, @NotNull String[] modeOfPp, @NotNull String typeOfPolicy) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.lifeCover = lifeCover;
		this.coverFor = coverFor;
		this.payFor = payFor;
		this.modeOfPp = modeOfPp;
		this.typeOfPolicy = typeOfPolicy;
	}

}
