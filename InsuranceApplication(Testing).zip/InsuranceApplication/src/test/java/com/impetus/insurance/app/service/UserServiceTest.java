package com.impetus.insurance.app.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.impl.UserService;

@SpringBootTest
class UserServiceTest {
	@InjectMocks
	UserService userServiceObject;

	@Mock
	UserRepository userRepo;

	@Mock
	User user;

	@BeforeEach
	void setUp() throws Exception {

		user = new User();
		user.setId(1);
		user.setEmail("deeksha@gmail.com");
		user.setPassword("XD");
	}

	@Test
	void testCreateNewAccount() {
		when(userRepo.save(user)).thenReturn(user);
		userServiceObject.createNewAcccount(user);
		verify(userRepo, times(1)).save(user);
		assertNotNull(user, "Not null");
	}

	@Test
	void testCreateNewAccount1() {
		User aObj = null;
		when(userRepo.save(aObj)).thenReturn(null);
		userServiceObject.createNewAcccount(aObj);
		verify(userRepo, times(1)).save(aObj);
		assertNull(aObj);
	}

	@Test
	void testValidateLogin() throws InvalidCredentialsException {

		when(userRepo.existsByEmail(user.getEmail())).thenReturn(true);
		when(userRepo.findByEmail(user.getEmail())).thenReturn(user);
		when(userServiceObject.validateLogin(user)).thenReturn(user);
		User obj = userServiceObject.validateLogin(user);
		verify(userRepo, times(2)).existsByEmail(user.getEmail());
	}

	@Test
	void testValidateLogin1() throws InvalidCredentialsException {

		User dummyUser = new User();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XD");

		when(userRepo.existsByEmail(dummyUser.getEmail())).thenReturn(false);
		when(userRepo.existsByPassword(dummyUser.getPassword())).thenReturn(false);
		assertThrows(InvalidCredentialsException.class, () -> userServiceObject.validateLogin(dummyUser));

	}

	@Test
	void testValidateLogin2() throws InvalidCredentialsException {

		User dummyUser = new User();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XDfgfhtffh");

		when(userRepo.existsByEmail(dummyUser.getEmail())).thenReturn(true);
		when(userRepo.findByEmail(user.getEmail())).thenReturn(user);
		assertNotEquals(user.getPassword().equals(dummyUser.getPassword()), true);
		assertThrows(InvalidCredentialsException.class, () -> userServiceObject.validateLogin(dummyUser));

	}

}
