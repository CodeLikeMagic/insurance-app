package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer>{

	boolean existsByEmail(String email);

	boolean existsByPassword(String password);

	User findByEmail(String email);
}
