package com.impetus.insurance.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserServiceI;

@Component
public class UserService implements UserServiceI {

	@Autowired
	UserRepository userRepo;

	@Override
	public User validateLogin(User userObject) throws InvalidCredentialsException {
		if (userRepo.existsByEmail(userObject.getEmail())) // if correct email
		{
			User object = userRepo.findByEmail(userObject.getEmail());
			if (userObject.getPassword().equals(object.getPassword())) {
				System.out.println("success!!!");
				return object;
			} else {
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} else {
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	public void createNewAcccount(User object) {
		userRepo.save(object);
	}
}
