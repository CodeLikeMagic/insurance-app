package com.impetus.insurance.app.rest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.service.impl.PolicyService;

@WebMvcTest(PolicyController.class)
class PolicyControllerTest extends AbstractTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	PolicyService policyService;

	Policy policy;

	@BeforeEach
	void setUpObjects() {

		policy = new Policy();
		policy.setId(1);
		policy.setLifeCover(new int[] { 500, 400, 300, 200, 100, 90, 80 });
		policy.setDescription("LIC");
		policy.setCoverFor(new int[] { 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15 });
		policy.setModeOfPp(new String[] { "One-time", "Monthly", "Yearly" });
		policy.setName("Sampoorna Raksha");
		policy.setPayFor(new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 });
		policy.setTypeOfPolicy("life");
	}

	@Test
	void testAdd() throws Exception {
		String uri = "/api/v1/policy";
		doNothing().when(policyService).add(policy);
		String inputJson = super.mapToJson(policy);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testDelete() throws Exception {
		String uri = "/api/v1/policy/2";
		doNothing().when(policyService).remove(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewById() throws Exception {
		String uri = "/api/v1/policy/2";
		doReturn(new Policy()).when(policyService).viewById(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testView() throws Exception {
		String uri = "/api/v1/policy";
		doReturn(new ArrayList<Policy>()).when(policyService).viewAll();
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testUpdate() throws Exception {
		String uri = "/api/v1/policy/1";
		String inputJson = super.mapToJson(policy);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

}
