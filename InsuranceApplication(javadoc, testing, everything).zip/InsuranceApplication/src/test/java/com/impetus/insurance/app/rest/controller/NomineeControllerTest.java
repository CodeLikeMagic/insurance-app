package com.impetus.insurance.app.rest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.service.impl.NomineeService;

@WebMvcTest(NomineeController.class)
public class NomineeControllerTest extends AbstractTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	NomineeService nomineeService;

	Nominee nominee;

	@BeforeEach
	void setUpObjects() {
		nominee = new Nominee();
		nominee.setId(1);
		nominee.setFirstName("Deeksha");
		nominee.setLastName("Patidar");
		nominee.setPhone(234566792);
		nominee.setAadharNo(1234456778);
		nominee.setRelation("Mother");
	}

	@Test
	void testAddNominee() throws Exception {
		String uri = "/api/v1/nominee";
		doReturn(nominee).when(nomineeService).add(nominee);
		String inputJson = super.mapToJson(nominee);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testDeleteNominee() throws Exception {
		String uri = "/api/v1/nominee/2";
		doNothing().when(nomineeService).remove(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewByAadhar() throws Exception {
		String uri = "/api/v1/nominee/224454621";
		doReturn(new Nominee()).when(nomineeService).findByAadhar(224454621);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

}
