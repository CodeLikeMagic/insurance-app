package com.impetus.insurance.app.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UnderWriterRepository;
import com.impetus.insurance.app.service.impl.UnderWriterService;

@SpringBootTest
class UnderWriterServiceTest {
	
	@InjectMocks
	UnderWriterService underWriterServiceObject;

	@Mock
	UnderWriterRepository uwRepo;

	@Mock
	UnderWriter underWriter;

	@BeforeEach
	void setUp() throws Exception {

		underWriter = new UnderWriter();
		underWriter.setId(1);
		underWriter.setEmail("deeksha@gmail.com");
		underWriter.setPassword("XD");
	}

	@Test
	void testCreateNewAccount() {
		when(uwRepo.save(underWriter)).thenReturn(underWriter);
		underWriterServiceObject.createNewAcccount(underWriter);
		verify(uwRepo, times(1)).save(underWriter);
		assertNotNull(underWriter, "Not null");
	}

	@Test
	void testCreateNewAccount1() {
		UnderWriter aObj = null;
		when(uwRepo.save(aObj)).thenReturn(null);
		underWriterServiceObject.createNewAcccount(aObj);
		verify(uwRepo, times(1)).save(aObj);
		assertNull(aObj);
	}

	@Test
	void testValidateLogin() throws InvalidCredentialsException {

		when(uwRepo.existsByEmail(underWriter.getEmail())).thenReturn(true);
		when(uwRepo.findByEmail(underWriter.getEmail())).thenReturn(underWriter);
		when(underWriterServiceObject.validateLogin(underWriter)).thenReturn(underWriter);
		UnderWriter obj = underWriterServiceObject.validateLogin(underWriter);
		verify(uwRepo, times(2)).existsByEmail(underWriter.getEmail());
	}

	@Test
	void testValidateLogin1() throws InvalidCredentialsException {

		UnderWriter dummyUser = new UnderWriter();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XD");

		when(uwRepo.existsByEmail(dummyUser.getEmail())).thenReturn(false);
		when(uwRepo.existsByPassword(dummyUser.getPassword())).thenReturn(false);
		assertThrows(InvalidCredentialsException.class, () -> underWriterServiceObject.validateLogin(dummyUser));

	}

	@Test
	void testValidateLogin2() throws InvalidCredentialsException {

		UnderWriter dummyUser = new UnderWriter();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XDfgfhtffh");

		when(uwRepo.existsByEmail(dummyUser.getEmail())).thenReturn(true);
		when(uwRepo.findByEmail(underWriter.getEmail())).thenReturn(underWriter);
		assertNotEquals(true, underWriter.getPassword().equals(dummyUser.getPassword()));
		assertThrows(InvalidCredentialsException.class, () -> underWriterServiceObject.validateLogin(dummyUser));

	}
}
