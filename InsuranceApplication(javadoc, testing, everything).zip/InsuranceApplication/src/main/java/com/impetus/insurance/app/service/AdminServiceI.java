package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

/**
 * This interface implements AdminService Interface,it declares the methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface AdminServiceI {

	/**
	 * This method handles Admin login
	 * 
	 * @param object inputs Admin object
	 * @return Admin object if login is successfull
	 * @throws InvalidCredentialsException
	 */
	public Admin validateLogin(Admin object) throws InvalidCredentialsException;

	/**
	 * This method handles Admin signup
	 * 
	 * @param object inputs Admin object
	 */
	public void createNewAcccount(Admin object);
}
