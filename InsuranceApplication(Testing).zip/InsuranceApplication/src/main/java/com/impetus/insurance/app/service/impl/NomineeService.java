package com.impetus.insurance.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.service.NomineeServiceI;

@Component
public class NomineeService implements NomineeServiceI{

	@Autowired
	NomineeRepository nomineeRepo;

	@Override
	public Nominee add(Nominee object) {
		System.out.println(object.toString());
		Nominee responseObject = nomineeRepo.findByAadharNo(object.getAadharNo());
		if(responseObject == null) {
			nomineeRepo.save(object);
		}
		return nomineeRepo.findByAadharNo(object.getAadharNo());
	}

	@Override
	public void remove(int Id) {
		nomineeRepo.deleteById(Id);
	}

	@Override
	public Nominee findByAadhar(long aNo) {
		return nomineeRepo.findByAadharNo(aNo);
	}

}
