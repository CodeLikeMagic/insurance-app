package com.impetus.insurance.app.exceptions;

/**
 * Raised when user tries to register with existing users email.
 * @author deeksha.patidar
 */
public class InvalidEmailIdException extends Exception{

	private static final long serialVersionUID = 1L;

	public InvalidEmailIdException() {
		super();
	}

	public InvalidEmailIdException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidEmailIdException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidEmailIdException(String message) {
		super(message);
	}

	public InvalidEmailIdException(Throwable cause) {
		super(cause);
	}

}
