package com.impetus.insurance.app.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.service.impl.NomineeService;

@SpringBootTest
class NomineeServiceTest {

	@InjectMocks
	NomineeService nomineeServiceObject;

	@Mock
	NomineeRepository nomineeeRepo;

	Nominee nominee;

	@BeforeEach
	void setUp() throws Exception {
		nominee = new Nominee();
		nominee.setId(1);
		nominee.setFirstName("Deeksha");
		nominee.setLastName("Patidar");
		nominee.setPhone(234566792);
		nominee.setAadharNo(1234456778);
		nominee.setRelation_ph("Mother");
	}

	@Test
	void add() {
		nomineeServiceObject.add(nominee);
		nomineeeRepo.save(nominee);
		verify(nomineeeRepo, times(2)).save(nominee);
		assertNotNull(nominee, "Not null");
	}

	@Test
	void remove() {
		nomineeServiceObject.remove(1);
		nomineeeRepo.deleteById(1);
		doNothing().when(nomineeeRepo).deleteById(1);
		verify(nomineeeRepo, times(2)).deleteById(1);
	}

	@Test
	void find() {
		nomineeServiceObject.findByAadhar(1122345632);
		nomineeeRepo.findByAadharNo(1122345632);
		doReturn(nominee).when(nomineeeRepo).findByAadharNo(1122345632);
		verify(nomineeeRepo, times(2)).findByAadharNo(1122345632);
	}
}
