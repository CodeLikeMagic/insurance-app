package com.impetus.insurance.app.rest.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;
import com.impetus.insurance.app.service.impl.PolicyService;

/**
 * This rest controller handles all the api calls for policy.
 * 
 * @author deeksha.patidar
 * @version 1.0
 */
@RestController
@RequestMapping("/api/v1/")
public class PolicyController {

	@Autowired
	PolicyService policyService;

	/**
	 * This method is post policy api, adds new policy
	 * 
	 * @param object
	 * @return HttpStatus
	 */
	@PostMapping("policy")
	public ResponseEntity<HttpStatus> add(@RequestBody @Valid Policy object) {
		policyService.add(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	/**
	 * This method is delete policy api, deletes a policy
	 * 
	 * @param id
	 * @throws InvalidPolicyIdException
	 */
	@DeleteMapping("policy/{id}")
	public void delete(@PathVariable("id") int id) throws InvalidPolicyIdException {
		policyService.remove(id);
	}

	/**
	 * This method is get policy api, gets by id
	 * 
	 * @param id
	 * @return Policy object
	 * @throws InvalidPolicyIdException
	 */
	@GetMapping("policy/{id}")
	public ResponseEntity<Policy> view(@PathVariable("id") int id) throws InvalidPolicyIdException {
		return new ResponseEntity<>(policyService.viewById(id), HttpStatus.OK);
	}

	/**
	 * This method is get policy api, gets all policies
	 * 
	 * @return List of Policy
	 */
	@GetMapping("policy")
	public ResponseEntity<List<Policy>> viewAll() {
		return new ResponseEntity<>(policyService.viewAll(), HttpStatus.OK);
	}

	/**
	 * This method is put policy api, updates policy
	 * 
	 * @param id
	 * @param object
	 * @return HttpStatus
	 * @throws InvalidPolicyIdException
	 */
	@PutMapping("policy/{id}")
	public ResponseEntity<HttpStatus> update(@PathVariable("id") int id, @RequestBody @Valid Policy object)
			throws InvalidPolicyIdException {
		policyService.edit(id, object);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

}
