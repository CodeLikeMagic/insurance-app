package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.Nominee;

public interface NomineeServiceI {

	public boolean add(Nominee object);

	public void remove(int Id);

	public Nominee findByAadhar(long aNo);
}
