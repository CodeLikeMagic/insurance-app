package com.impetus.insurance.app.service;

import com.impetus.insurance.app.dto.RegisteredUserDto;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface RegisteredUserServiceI {
	public boolean validateLogin(RegisteredUserDto object) throws InvalidCredentialsException;

	public void createNewAccount(RegisteredUserDto object);

}
