package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import com.impetus.insurance.app.entity.UnderWriter;

public interface UnderWriterRepository extends CrudRepository<UnderWriter, Integer> {
	boolean existsByEmail(String email);

	boolean existsByPassword(String password);
	
	UnderWriter findByEmail(String email);
}
