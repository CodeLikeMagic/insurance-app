package com.impetus.insurance.app.exceptions;

public class InvalidPolicyIdException extends Exception{

	private static final long serialVersionUID = 1L;
	//serializing an object //for object transfer it helps
	//marker interface
	public InvalidPolicyIdException(String s)
	{
		super(s);
	}
}
