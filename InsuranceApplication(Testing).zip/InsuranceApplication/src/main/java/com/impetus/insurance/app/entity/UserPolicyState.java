package com.impetus.insurance.app.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "owned_policy_state")
public class UserPolicyState {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	@NotNull
	@Column(name = "premium")
	long premium;

	@NotNull
	@OneToOne
	Nominee nominee;

	@NotNull
	@OneToOne
	User owner;

	@NotNull
	@OneToOne
	Policy policy;

	String summary;

	@NotNull
	Timestamp ts;

	@NotNull
	String status;

	public UserPolicyState() {

	}

	public UserPolicyState(int id, @NotNull long premium, @NotNull Nominee nominee, @NotNull User owner,
			@NotNull Policy policy, String summary, Timestamp ts, String status) {
		super();
		this.id = id;
		this.premium = premium;
		this.nominee = nominee;
		this.owner = owner;
		this.policy = policy;
		this.summary = summary;
		this.ts = ts;
		this.status = status;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp l) {
		this.ts = l;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Nominee getNominee() {
		return nominee;
	}

	public void setNominee(Nominee nominee) {
		this.nominee = nominee;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getPremium() {
		return premium;
	}

	public void setPremium(long d) {
		this.premium = d;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	public void setONominee(Optional<Nominee> nominee) {
		// TODO Auto-generated method stub
		this.nominee = nominee.get();
	}

	public void setOOwner(Optional<User> owner) {
		// TODO Auto-generated method stub
		this.owner = owner.get();
	}

	public void setOPolicy(Optional<Policy> policy) {
		// TODO Auto-generated method stub
		this.policy = policy.get();
	}

	@Override
	public String toString() {
		return "UserPolicyState [id=" + id + ", premium=" + premium + ", nominee=" + nominee + ", owner=" + owner
				+ ", policy=" + policy + ", summary=" + summary + ", ts=" + ts + ", status=" + status + "]";
	}

}
