package com.impetus.insurance.app.service;

import com.impetus.insurance.app.dto.AdminDto;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface AdminServiceI {
	
	public boolean validateLogin(AdminDto object) throws InvalidCredentialsException;
	
	public void createNewAcccount(AdminDto object);
}
