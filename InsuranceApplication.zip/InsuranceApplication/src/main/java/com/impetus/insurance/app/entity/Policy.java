package com.impetus.insurance.app.entity;

public class Policy {
	
	String name;
	String description;// description
	String[] lifeCover;
	String[] coverFor;
	String[] payFor;
	String[] modeOfPp;
	String typeOfPolicy; //life or dental

	public Policy(String name, String description, String[] lifeCover, String[] coverFor, String[] payFor,
			String[] modeOfPp) {
		super();
		this.name = name;
		this.description = description;
		this.lifeCover = lifeCover;
		this.coverFor = coverFor;
		this.payFor = payFor;
		this.modeOfPp = modeOfPp;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String[] getLifeCover() {
		return lifeCover;
	}

	public void setLifeCover(String[] lifeCover) {
		this.lifeCover = lifeCover;
	}

	public String[] getCoverFor() {
		return coverFor;
	}

	public void setCoverFor(String[] coverFor) {
		this.coverFor = coverFor;
	}

	public String[] getPayFor() {
		return payFor;
	}

	public void setPayFor(String[] payFor) {
		this.payFor = payFor;
	}

	public String[] getModeOfPp() {
		return modeOfPp;
	}

	public void setModeOfPp(String[] modeOfPp) {
		this.modeOfPp = modeOfPp;
	}

}
