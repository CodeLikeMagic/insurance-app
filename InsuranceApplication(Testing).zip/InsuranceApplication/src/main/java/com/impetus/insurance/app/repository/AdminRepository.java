package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.Admin;

@Repository
public interface AdminRepository extends CrudRepository<Admin, Integer> {
	boolean existsByEmail(String email);

	boolean existsByPassword(String password);
	
	Admin findByEmail(String email);
}
