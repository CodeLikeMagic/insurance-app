package com.impetus.insurance.app.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.PasswordEncrypt;
import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UnderWriterRepository;
import com.impetus.insurance.app.service.UnderWriterServiceI;

/**
 * This class implements UnderWriter Service
 * 
 * @author deeksha.patidar
 *
 */
@Component
public class UnderWriterService implements UnderWriterServiceI {

	@Autowired
	UnderWriterRepository underwriterRepo;

	final Logger logger = LogManager.getLogger(AdminService.class);

	/**
	 * This method validates login of UnderWriter, returns that UnderWriter object
	 * if login is successful else InvalidCredentialsException is thrown
	 */
	@Override
	public UnderWriter validateLogin(UnderWriter object) throws InvalidCredentialsException {
		if (underwriterRepo.existsByEmail(object.getEmail())) // if correct email
		{
			UnderWriter obj = underwriterRepo.findByEmail(object.getEmail());
			String checker = PasswordEncrypt.EncryptPass(object.getPassword());
			if (checker.equals(obj.getPassword())) {
				logger.info("Login successsfull.");
				return object;
			} else {
				logger.error("Invalid password.");
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} else {
			logger.warn("Invalid email.");
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	/**
	 * This method creates new UnderWriter account
	 * 
	 */
	@Override
	public void createNewAcccount(UnderWriter object) {
		underwriterRepo.save(object);
		logger.info("Account created successsfully.");
	}

}
