package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface UserServiceI {

	public User validateLogin(User object) throws InvalidCredentialsException;

	public void createNewAcccount(User object);

}
