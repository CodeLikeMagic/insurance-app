package com.impetus.insurance.app.service.impl;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.dto.RegisteredUserDto;
import com.impetus.insurance.app.entity.RegisteredUser;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.RegisteredUserRepository;
import com.impetus.insurance.app.service.RegisteredUserServiceI;

@Component
public class RegisteredUserService implements RegisteredUserServiceI {

	@Autowired
	RegisteredUserRepository ruserRepo;

	@Autowired
	ModelMapper mapper;

	public boolean validateLogin(RegisteredUserDto object) throws InvalidCredentialsException {
		// TODO Auto-generated method stub
		RegisteredUser ruser = mapper.map(object, RegisteredUser.class);
		if(ruserRepo.existsByEmail(ruser.getEmail()) && ruserRepo.existsByPassword(ruser.getPassword()))
		{
			return true;
		}
		else
		{
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	@Override
	public void createNewAccount(RegisteredUserDto object) {
		// TODO Auto-generated method stub
		RegisteredUser ruser = mapper.map(object, RegisteredUser.class);
		ruserRepo.save(ruser);
	}
}
