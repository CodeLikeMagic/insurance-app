package com.impetus.insurance.app.entity;

import java.util.Date;

public class UserDetails {

	// email fk
	String gender;
	Date dob;
	String pincode;
	String city;
	String income;
	String education;
	String occupation;
	String nationality;

	public UserDetails(String gender, Date dob, String pincode, String city, String income, String education,
			String occupation, String nationality) {
		super();
		this.gender = gender;
		this.dob = dob;
		this.pincode = pincode;
		this.city = city;
		this.income = income;
		this.education = education;
		this.occupation = occupation;
		this.nationality = nationality;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
}
