package com.impetus.insurance.app.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.dto.AdminDto;
import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.AdminRepository;
import com.impetus.insurance.app.service.AdminServiceI;


@Component
public class AdminService implements AdminServiceI{

	@Autowired 
	AdminRepository adminRepo;
	
	@Autowired
	ModelMapper mapper;
	
	@Override
	public boolean validateLogin(AdminDto object) throws InvalidCredentialsException {
		// TODO Auto-generated method stub
		Admin admin = mapper.map(object, Admin.class);
		if(adminRepo.existsByEmail(admin.getEmail()) && adminRepo.existsByPassword(admin.getPassword()))
		{
			return true;
		}
		else
		{
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	@Override
	public void createNewAcccount(AdminDto object) {
		// TODO Auto-generated method stub
		Admin admin = mapper.map(object, Admin.class);
		adminRepo.save(admin);
	}
}
