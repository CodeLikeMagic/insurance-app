package com.impetus.insurance.app.repository;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

import com.impetus.insurance.app.entity.Nominee;

@EnableJpaRepositories
public interface NomineeRepository extends CrudRepository<Nominee, Integer>{
	Nominee findByAadharNo(long aadhar_no);
}
