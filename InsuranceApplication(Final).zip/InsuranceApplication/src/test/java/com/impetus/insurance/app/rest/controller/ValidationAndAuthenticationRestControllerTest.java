package com.impetus.insurance.app.rest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.service.impl.AdminService;
import com.impetus.insurance.app.service.impl.UnderWriterService;
import com.impetus.insurance.app.service.impl.UserService;

@WebMvcTest(ValidationAndAuthenticationController.class)
class ValidationAndAuthenticationRestControllerTest extends AbstractTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	AdminService adminService;

	@MockBean
	UnderWriterService underwriterService;

	@MockBean
	UserService userService;

	User user;
	Admin admin;
	UnderWriter underwriter;

	@BeforeEach
	void setUpObjects() throws ParseException {

		underwriter = new UnderWriter();
		underwriter.setId(1);
		underwriter.setEmail("user1");
		underwriter.setPassword("user1");

		admin = new Admin();
		admin.setId(1);
		admin.setEmail("D");
		admin.setPassword("D01");

		user = new User();
		user.setId(1);
		user.setFirstName("D");
		user.setLastName("P");
		user.setOccupation("Doc");
		user.setPassword("ijfifs");
		user.setNationality("Indian");
		user.setPincode(123452);
		user.setAge(13);
		user.setCity("Indore");
		user.setEducation("BBA");
		user.setEmail("dp@gmail.com");
		user.setGender("Female");
		user.setIncome("500000");
		String d = "01-01-2000";
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date d1 = formatter.parse(d);
		user.setDob(d1);
		// Date d = new Date();
		// d.setDate(20001);
		// user.setDob(d);
		user.setIsSmoker(true);
	}

	@Test
	void testUnderWriterLogin() throws Exception {
		String uri = "/api/v1/underwriter/login";
		doReturn(underwriter).when(underwriterService).validateLogin(underwriter);
		String inputJson = super.mapToJson(underwriter);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

	@Test
	void testAdminLogin() throws Exception {
		String uri = "/api/v1/admin/login";
		doReturn(admin).when(adminService).validateLogin(admin);
		String inputJson = super.mapToJson(admin);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

	@Test
	void testUserLogin() throws Exception {
		String uri = "/api/v1/users/login";
		doReturn(user).when(userService).validateLogin(user);
		String inputJson = super.mapToJson(user);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

	@Test
	void testUnderWriterSignUp() throws Exception {
		String uri = "/api/v1/underwriter";
		doNothing().when(underwriterService).createNewAcccount(underwriter);
		String inputJson = super.mapToJson(underwriter);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testAdminSignUp() throws Exception {
		String uri = "/api/v1/admin";
		doNothing().when(adminService).createNewAcccount(admin);
		String inputJson = super.mapToJson(admin);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testUserSignUp() throws Exception {
		String uri = "/api/v1/users";
		doNothing().when(userService).createNewAcccount(user);
		String inputJson = super.mapToJson(user);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}
}
