package com.impetus.insurance.app.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.AdminRepository;
import com.impetus.insurance.app.service.AdminServiceI;


@Component
public class AdminService implements AdminServiceI{

	@Autowired 
	AdminRepository adminRepo;
	
	@Autowired
	ModelMapper mapper;
	
	@Override
	public boolean validateLogin(Admin object) throws InvalidCredentialsException {
		if(adminRepo.existsByEmail(object.getEmail()) && adminRepo.existsByPassword(object.getPassword()))
		{
			return true;
		}
		else
		{
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	@Override
	public void createNewAcccount(Admin object) {
		adminRepo.save(object);
	}
}
