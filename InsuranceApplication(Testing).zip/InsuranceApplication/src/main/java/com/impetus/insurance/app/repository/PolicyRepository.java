package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import com.impetus.insurance.app.entity.Policy;

public interface PolicyRepository extends CrudRepository<Policy, Integer>{

}
