package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.User;

/**
 * This interface implements User Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface UserRepository extends CrudRepository<User, Integer>{

	/**This method returns true or false on checking whether that email exists or not 
	 * @param email inputs string value of email
	 * @return boolean
	 */
	boolean existsByEmail(String email);

	/**This method returns User object with that email
	 * @param email inputs string value of email
	 * @return User object
	 */
	User findByEmail(String email);
}
