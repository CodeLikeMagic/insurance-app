package com.impetus.insurance.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.impetus.insurance.app.entity.UserPolicyState;

@Repository
public interface UserPolicyStateRepository extends CrudRepository<UserPolicyState, Integer>{

	List<UserPolicyState> findAllByStatus(String status);
	
	List<UserPolicyState> findAllByOwnerId(int userId);
	
	List<UserPolicyState> findAllByPolicyId(int policyId);
}
