package com.impetus.insurance.app.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.PasswordEncrypt;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.exceptions.InvalidEmailIdException;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserServiceI;

/**
 * This class implements User Service
 * @author deeksha.patidar
 *
 */
@Component
public class UserService implements UserServiceI {

	@Autowired
	UserRepository userRepo;

	final Logger logger = LogManager.getLogger(UserService.class);
	
	/**
	 * This method validates login of User, 
	 * returns that User object if login is successful
	 * else InvalidCredentialsException is thrown
	 */
	@Override
	public User validateLogin(User userObject) throws InvalidCredentialsException {
		if (userRepo.existsByEmail(userObject.getEmail())) // if correct email
		{
			User object = userRepo.findByEmail(userObject.getEmail());
			String checker = PasswordEncrypt.EncryptPass(userObject.getPassword()) ;
			if (checker.equals(object.getPassword())) {
				logger.info("Login successsfull.");
				return object;
			} else {
				logger.error("Invalid password.");
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} else {
			logger.warn("Invalid email.");
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	/**This method creates new User account
	 * @throws InvalidEmailIdException 
	 *	
	 */
	public void createNewAcccount(User object) throws InvalidEmailIdException {
		if (userRepo.existsByEmail(object.getEmail())) {
			logger.info("ERROR !!!...same email to create new account");
			throw new InvalidEmailIdException("This email is already present , please use another email");
			
		}else {
			userRepo.save(object);
			logger.info("Account created successsfully.");
		}
		
	}
}
