package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.Nominee;

/**
 * This interface implements Nominee Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface NomineeRepository extends CrudRepository<Nominee, Integer>{

	/**This method returns Nominee object with that Aadhar Number
	 * @param aadharNo inputs string value of aadharNo
	 * @return Nominee object
	 */
	Nominee findByAadharNo(long aadharNo);
}
