package com.impetus.insurance.app.rest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.service.impl.NomineeService;
import com.impetus.insurance.app.service.impl.PolicyService;
import com.impetus.insurance.app.service.impl.UserPolicyStateService;

@WebMvcTest(PolicyController.class)
class PolicyControllerTest extends AbstractTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	PolicyService policyService;

	@MockBean
	NomineeService nomineeService;

	@MockBean
	UserPolicyStateService uspService;

	Nominee nominee;
	Policy policy;
	UserPolicyStateDto uspObject;
	UserPolicyState reqObject;
	User user;

	@BeforeEach
	void setUpObjects() {

		user = new User();
		user.setId(1);
		user.setFirstName("D");
		user.setLastName("P");
		user.setAge(13);
		user.setCity("Indore");
		user.setEducation("BBA");
		user.setEmail("dp@gmail.com");
		user.setGender("Female");
		user.setIncome("500000");
		Date d = new Date();
		d.setDate(20001);
		user.setDob(d);
		user.setIsSmoker(true);

		policy = new Policy();
		policy.setId(1);
		policy.setLifeCover(new int[] { 500, 400, 300, 200, 100, 90, 80 });
		policy.setDescription("LIC");
		policy.setCoverFor(new int[] { 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15 });
		policy.setModeOfPp(new String[] { "One-time", "Monthly", "Yearly" });
		policy.setName("Sampoorna Raksha");
		policy.setPayFor(new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 });
		policy.setTypeOfPolicy("life");

		nominee = new Nominee();
		nominee.setId(1);
		nominee.setFirstName("Deeksha");
		nominee.setLastName("Patidar");
		nominee.setPhone(234566792);
		nominee.setAadharNo(1234456778);
		nominee.setRelation("Mother");

		uspObject = new UserPolicyStateDto();
		uspObject.setId(1);
		uspObject.setNominee(5);
		uspObject.setOwner(3);
		uspObject.setPolicy(2);
		uspObject.setPremium(1235243);
		uspObject.setStatus("PENDING");
		uspObject.setSummary("Life cover : xyz");
		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		uspObject.setTs(ts);

		reqObject = new UserPolicyState();
		reqObject.setId(1);
		reqObject.setNominee(nominee);
		reqObject.setOwner(user);
		reqObject.setPolicy(policy);
		reqObject.setPremium(1235243);
		reqObject.setStatus("PENDING");
		reqObject.setSummary("Life cover : xyz");
		Date date1 = new Date();
		Timestamp ts1 = new Timestamp(date1.getTime());
		reqObject.setTs(ts1);
	}

	@Test
	void testAdd() throws Exception {
		String uri = "/api/v1/policy";
		doNothing().when(policyService).add(policy);
		String inputJson = super.mapToJson(policy);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testDelete() throws Exception {
		String uri = "/api/v1/policy/2";
		doNothing().when(policyService).remove(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewById() throws Exception {
		String uri = "/api/v1/policy/2";
		doReturn(new Policy()).when(policyService).viewById(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testView() throws Exception {
		String uri = "/api/v1/policy";
		doReturn(new ArrayList<Policy>()).when(policyService).viewAll();
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testUpdate() throws Exception {
		String uri = "/api/v1/policy/1";
		String inputJson = super.mapToJson(policy);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}

/////nominee

	@Test
	void testAddNominee() throws Exception {
		String uri = "/api/v1/nominee";
		doReturn(nominee).when(nomineeService).add(nominee);
		String inputJson = super.mapToJson(nominee);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testDeleteNominee() throws Exception {
		String uri = "/api/v1/nominee/2";
		doNothing().when(nomineeService).remove(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.delete(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewByAadhar() throws Exception {
		String uri = "/api/v1/nominee/224454621";
		doReturn(new Nominee()).when(nomineeService).findByAadhar(224454621);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testAddReqObj() throws Exception {
		String uri = "/api/v1/requestObject";
		doNothing().when(uspService).add(uspObject);
		String inputJson = super.mapToJson(uspObject);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(201, status);
	}

	@Test
	void testViewByReqUserId() throws Exception {
		String uri = "/api/v1/requestObject/user/2";
		doReturn(new ArrayList<UserPolicyState>()).when(uspService).getMyPolicies(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewByReqId() throws Exception {
		String uri = "/api/v1/requestObject/2";
		doReturn(new UserPolicyState()).when(uspService).viewById(2);
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewByReqObjectByStatus() throws Exception {
		String uri = "/api/v1/requestObject/all/PENDING";
		doReturn(new ArrayList<UserPolicyState>()).when(uspService).getRequestObjectByStatus("AWAITING");
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testViewAllReqObject() throws Exception {
		String uri = "/api/v1/requestObject";
		doReturn(new ArrayList<UserPolicyState>()).when(uspService).getAll();
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
	}

	@Test
	void testReqUpdate() throws Exception {
		String uri = "/api/v1/requestObject/update";
		String inputJson = super.mapToJson(reqObject);
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(202, status);
	}
}
