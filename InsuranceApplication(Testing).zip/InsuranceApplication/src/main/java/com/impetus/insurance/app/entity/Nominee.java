package com.impetus.insurance.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "nominee")
public class Nominee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	@NotNull
	@Column(name = "first_name")
	String firstName;

	@NotNull
	@Column(name = "last_name")
	String lastName;

	@NotNull
	String relation_ph;


	long aadharNo;

	@NotNull
	long phone;

	public Nominee() {

	}

	public Nominee(int id, @NotNull String firstName, @NotNull String lastName, @NotNull String relation_ph,
		 long aadharNo, @NotNull long phone) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relation_ph = relation_ph;
		this.aadharNo = aadharNo;
		this.phone = phone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRelation_ph() {
		return relation_ph;
	}

	public void setRelation_ph(String relation_ph) {
		this.relation_ph = relation_ph;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Nominee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", relation_ph="
				+ relation_ph + ", aadharNo=" + aadharNo + ", phone=" + phone + "]";
	}

}
