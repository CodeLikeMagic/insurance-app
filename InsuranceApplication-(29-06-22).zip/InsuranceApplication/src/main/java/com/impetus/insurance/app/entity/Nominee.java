package com.impetus.insurance.app.entity;

public class Nominee {
	
	int id;
	String username;
	String relation_ph;
	String aadhar_no;
	String phone;

	public Nominee(String username, String relation, String aadhar_no, String phone) {
		super();
		this.username = username;
		this.relation_ph = relation;
		this.aadhar_no = aadhar_no;
		this.phone = phone;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRelation() {
		return relation_ph;
	}

	public void setRelation(String relation) {
		this.relation_ph = relation;
	}

	public String getAadhar_no() {
		return aadhar_no;
	}

	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
