package com.impetus.insurance.app.rest.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.service.impl.UserService;

@RestController
@RequestMapping("/api/v1/")
public class ValidationAndAuthenticationController {

	@Autowired
	UserService userService;

///////users
	@GetMapping("/users")
	public ResponseEntity<List<User>> viewAll() {
		return new ResponseEntity<>(userService.viewAll(), HttpStatus.OK);
	}

	@PostMapping("/users/login")
	public ResponseEntity<User> userLogin(@RequestBody User object) throws InvalidCredentialsException {
		//userService.validateLogin(object);
		//return new ResponseEntity<>(HttpStatus.ACCEPTED);
		return new ResponseEntity<>(userService.validateLogin(object), HttpStatus.ACCEPTED);
	}
	
	@PostMapping("/users")
	public ResponseEntity<HttpStatus> userSignUp(@RequestBody @Valid User object) {
		System.out.println(object.toString());
		object.setAge(User.calculateAgeWithJava7(object.getDob()));
		userService.createNewAcccount(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
		
/////////admin
	}
}
