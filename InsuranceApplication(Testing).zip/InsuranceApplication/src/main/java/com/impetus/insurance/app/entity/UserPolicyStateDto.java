package com.impetus.insurance.app.entity;

import java.sql.Timestamp;

public class UserPolicyStateDto {

	int id;

	long premium;

	int nominee;

	int owner;

	int policy;

	String summary;

	Timestamp ts;

	String status;

	public UserPolicyStateDto() {

	}

	public UserPolicyStateDto(int id, long premium, int nominee, int owner, int policy, String summary, Timestamp ts,
			String status) {
		super();
		this.id = id;
		this.premium = premium;
		this.nominee = nominee;
		this.owner = owner;
		this.policy = policy;
		this.summary = summary;
		this.ts = ts;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getPremium() {
		return premium;
	}

	public void setPremium(long premium) {
		this.premium = premium;
	}

	public int getNominee() {
		return nominee;
	}

	public void setNominee(int nominee) {
		this.nominee = nominee;
	}

	public int getOwner() {
		return owner;
	}

	public void setOwner(int owner) {
		this.owner = owner;
	}

	public int getPolicy() {
		return policy;
	}

	public void setPolicy(int policy) {
		this.policy = policy;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp ts) {
		this.ts = ts;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UserPolicyStateDto [id=" + id + ", premium=" + premium + ", nominee=" + nominee + ", owner=" + owner
				+ ", policy=" + policy + ", summary=" + summary + ", ts=" + ts + ", status=" + status + "]";
	}

}
