package com.impetus.insurance.app.entity;

import java.math.BigInteger;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the OrderRequest.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
public class OrderRequest {

	String customerName;
	String email;
	String phoneNumber;
	BigInteger amount;

}