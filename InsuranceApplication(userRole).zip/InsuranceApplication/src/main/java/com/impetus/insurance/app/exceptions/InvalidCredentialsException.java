package com.impetus.insurance.app.exceptions;


/**
 * Raised when user enters invalid credentials.
 * 
 * @author deeksha.patidar
 *
 */
public class InvalidCredentialsException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public InvalidCredentialsException(String s)
	{
		super(s);
	}
}