package com.impetus.insurance.app.service;

import java.util.List;

import com.impetus.insurance.app.entity.*;

public interface UserPolicyStateServiceI {
	public void add(UserPolicyStateDto object);
	
	public List<UserPolicyState> getMyPolicies(int userId);
}
