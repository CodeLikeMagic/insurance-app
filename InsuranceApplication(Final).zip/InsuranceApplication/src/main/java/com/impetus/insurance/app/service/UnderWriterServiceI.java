package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface UnderWriterServiceI {

	public UnderWriter validateLogin(UnderWriter object) throws InvalidCredentialsException;
	
	public void createNewAcccount(UnderWriter object);
}
