package com.impetus.insurance.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserPolicyStateServiceI;

@Component
public class UserPolicyStateService implements UserPolicyStateServiceI {

	public static final String APPROVED = "APPROVED";
	public static final String PENDING = "PENDING";
	public static final String REJECTED = "REJECTED";
	public static final String AWAITING = "AWAITING";

	@Autowired
	UserPolicyStateRepository uspRepo;

	@Autowired
	PolicyRepository policyRepo;

	@Autowired
	NomineeRepository nomineeRepo;

	@Autowired
	UserRepository userRepo;

	@Scheduled(initialDelay = 100000, fixedDelay = 120000)
	public void autoApproval() {

		List<UserPolicyState> listOfRequests = (List<UserPolicyState>) uspRepo.findAll();

		List<UserPolicyState> listOfPendingRequests = listOfRequests.stream()
				.filter(x -> (x.getStatus().equals(PENDING))).collect(Collectors.toList());

		List<UserPolicyState> batchOfUpdateRequests = new ArrayList<>();

		for (UserPolicyState request : listOfPendingRequests) {
			boolean approveFlag = false;
			User obj = null;
			int age = 0;
			Optional<User> fetchedObj = userRepo.findById(request.getOwner().getId());

			if (fetchedObj.isPresent()) {
				obj = fetchedObj.get();
				age = obj.getAge();
			}

			long finalPremium = request.getPremium();
			long income = Long.parseLong(obj.getIncome());

			// underage
			if (age < 18) {
				request.setStatus(AWAITING);
				approveFlag = true;
			}

			// based on income, final premium and mode of pay
			String summary = request.getSummary();
			int payFor = fetchCoverFor(summary);
			int div1;
			int div2;
			int div3;
			div1 = StringUtils.indexOf(summary, "Monthly");
			div2 = StringUtils.indexOf(summary, "One-time");
			div3 = StringUtils.indexOf(summary, "Yearly");

			if (div1 > 0 && ((income / 12) < finalPremium)) {
				request.setStatus(AWAITING);
				approveFlag = true;
			}

			if (div2 > 0 || div3 > 0 && ((income) < finalPremium)) {
				request.setStatus(AWAITING);
				approveFlag = true;
			}

			if (age + 20 < payFor) {
				request.setStatus(AWAITING);
				approveFlag = true;
			}

			// all conditions passed request is approved
			if (!approveFlag) {
				request.setStatus(APPROVED);
			}

			batchOfUpdateRequests.add(request);
		}
		for (UserPolicyState x : batchOfUpdateRequests) {
			update(x.getId(), x);
		}
	}

	public int fetchCoverFor(String summary) {
		StringBuilder s = new StringBuilder();

		int cnt = 0;

		for (int i = 0; i < summary.length(); i++) {
			if (cnt == 2) {
				if (s.length() <= 2 && summary.charAt(i) != 'y') {
					boolean flag = Character.isDigit(summary.charAt(i));
					if (flag) {
						s.append(summary.charAt(i));
					}
				} else {
					break;
				}
			} else if (summary.charAt(i) == ':') {
				cnt++;
			}
		}

		return Integer.parseInt(s.toString()); // coverFor
	}

	@Override
	public void add(UserPolicyStateDto object) {
		UserPolicyState uspObject = new UserPolicyState();

		uspObject.setONominee(nomineeRepo.findById(object.getNominee()));
		uspObject.setOOwner(userRepo.findById(object.getOwner()));
		uspObject.setOPolicy(policyRepo.findById(object.getPolicy()));
		uspObject.setPremium(object.getPremium());
		uspObject.setSummary(object.getSummary());

		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());

		uspObject.setTs(ts);
		uspObject.setStatus(PENDING);

		uspRepo.save(uspObject);
	}

	public UserPolicyState viewById(int id) {
		Optional<UserPolicyState> pObject = Optional.ofNullable(uspRepo.findById(id)).get();

		UserPolicyState object = null;
		if (pObject.isPresent()) {
			object = pObject.get();
		}
		return object;
	}

	public UserPolicyState update(int id, UserPolicyState object) {
		if (viewById(id).getId() == id) {
			uspRepo.save(object);
		}
		return object;
	}

	public List<UserPolicyState> getMyPolicies(int userId) {
		return uspRepo.findAllByOwnerId(userId);
	}

	public List<UserPolicyState> getRequestObjectByStatus(String status) {
		return uspRepo.findAllByStatus(status);
	}

	public List<UserPolicyState> getAll() {
		return (List<UserPolicyState>) uspRepo.findAll();
	}

}
