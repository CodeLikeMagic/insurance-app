package com.impetus.insurance.app.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPolicyStateServiceTest {

}
