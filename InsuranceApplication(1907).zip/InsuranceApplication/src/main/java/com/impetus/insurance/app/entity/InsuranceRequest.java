package com.impetus.insurance.app.entity;

import java.sql.Timestamp;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Table(name = "insurance_requests")
public class InsuranceRequest {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@NotNull
	UserPolicyState ownedPolicyState;

	@NotNull
	Timestamp ts;

	@NotNull
	String status;

	public InsuranceRequest() {

	}

	public InsuranceRequest(int id, @NotNull UserPolicyState ownedPolicyState, @NotNull Timestamp ts,
			@NotNull String status) {
		super();
		this.id = id;
		this.ownedPolicyState = ownedPolicyState;
		this.ts = ts;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public UserPolicyState getOwnedPolicyState() {
		return ownedPolicyState;
	}

	public void setOwnedPolicyState(UserPolicyState ownedPolicyState) {
		this.ownedPolicyState = ownedPolicyState;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp ts) {
		this.ts = ts;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "InsuranceRequest [id=" + id + ", ownedPolicyState=" + ownedPolicyState + ", ts=" + ts + ", status="
				+ status + "]";
	}
}
