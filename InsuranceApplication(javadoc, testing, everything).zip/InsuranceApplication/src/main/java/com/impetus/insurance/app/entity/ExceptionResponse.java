package com.impetus.insurance.app.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the ExceptionResponse for ExceptionHandler.
 * 
 * @author deeksha.patidar
 *
 */

@Getter
@Setter
@ToString
public class ExceptionResponse {

	/**
	 * String value for timestamp
	 */
	String timestamp;
	/**
	 * String value for error
	 */
	String error;
	/**
	 * String value for status
	 */
	String status;
	/**
	 * String value for uri path
	 */
	String path;

	/**
	 * Default Constructor
	 */
	public ExceptionResponse() {
		
	}

}
