package com.impetus.insurance.app.service.impl;

import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserServiceI;

@Component
public class UserService implements UserServiceI {

	@Autowired 
	UserRepository userRepo;
	
	@Autowired
	ModelMapper mapper;
	
	
	@Override
	public boolean validateLogin(User userObject) throws InvalidCredentialsException {
		System.out.println(userRepo.existsByEmail(userObject.getEmail()) + userObject.getEmail());
		System.out.println(userRepo.existsByPassword(userObject.getPassword()) + userObject.getPassword());
		if(userRepo.existsByEmail(userObject.getEmail()) && userRepo.existsByPassword(userObject.getPassword()))
		{
			System.out.println("success!!!");
			return true;
		}
		else
		{
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	@Override
	public List<User> viewAll() {
		List<User> listUsers = (List<User>) userRepo.findAll();
		if (listUsers.isEmpty()) {
			//
		}
		return listUsers;
	}

	public void createNewAcccount(User object) {
		userRepo.save(object);
	}
}
