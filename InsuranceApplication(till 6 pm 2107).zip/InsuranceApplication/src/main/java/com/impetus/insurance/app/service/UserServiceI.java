package com.impetus.insurance.app.service;

import java.util.List;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

public interface UserServiceI {

	public User validateLogin(User object) throws InvalidCredentialsException;

	public void createNewAcccount(User object);

	public List<User> viewAll();
}
