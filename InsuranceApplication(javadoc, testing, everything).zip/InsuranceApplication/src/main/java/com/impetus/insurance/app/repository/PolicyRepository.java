package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.impetus.insurance.app.entity.Policy;

/**
 * This interface implements Policy Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface PolicyRepository extends CrudRepository<Policy, Integer>{

}
