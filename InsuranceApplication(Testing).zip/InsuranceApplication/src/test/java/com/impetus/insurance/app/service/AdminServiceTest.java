package com.impetus.insurance.app.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.AdminRepository;
import com.impetus.insurance.app.service.impl.AdminService;

@SpringBootTest
class AdminServiceTest {

	@InjectMocks
	AdminService adminServiceObject;

	@Mock
	AdminRepository adminRepo;

	@Mock
	Admin admin;

	@BeforeEach
	void setUp() throws Exception {

		admin = new Admin();
		admin.setId(1);
		admin.setEmail("deeksha@gmail.com");
		admin.setPassword("XD");
	}

	@Test
	void testCreateNewAccount() {
		when(adminRepo.save(admin)).thenReturn(admin);
		adminServiceObject.createNewAcccount(admin);
		verify(adminRepo, times(1)).save(admin);
		assertNotNull(admin, "Not null");
	}

	@Test
	void testCreateNewAccount1() {
		Admin aObj = null;
		when(adminRepo.save(aObj)).thenReturn(null);
		adminServiceObject.createNewAcccount(aObj);
		verify(adminRepo, times(1)).save(aObj);
		assertNull(aObj);
	}

	@Test
	void testValidateLogin() throws InvalidCredentialsException {

		when(adminRepo.existsByEmail(admin.getEmail())).thenReturn(true);
		when(adminRepo.findByEmail(admin.getEmail())).thenReturn(admin);
		when(adminServiceObject.validateLogin(admin)).thenReturn(admin);
		Admin obj = adminServiceObject.validateLogin(admin);
		verify(adminRepo, times(2)).existsByEmail(admin.getEmail());
	}

	@Test
	void testValidateLogin1() throws InvalidCredentialsException {

		Admin dummyUser = new Admin();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XD");

		when(adminRepo.existsByEmail(dummyUser.getEmail())).thenReturn(false);
		when(adminRepo.existsByPassword(dummyUser.getPassword())).thenReturn(false);
		assertThrows(InvalidCredentialsException.class, () -> adminServiceObject.validateLogin(dummyUser));

	}

	@Test
	void testValidateLogin2() throws InvalidCredentialsException {

		Admin dummyUser = new Admin();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XDfgfhtffh");

		when(adminRepo.existsByEmail(dummyUser.getEmail())).thenReturn(true);
		when(adminRepo.findByEmail(admin.getEmail())).thenReturn(admin);
		assertNotEquals(admin.getPassword().equals(dummyUser.getPassword()), true);
		assertThrows(InvalidCredentialsException.class, () -> adminServiceObject.validateLogin(dummyUser));

	}

}
