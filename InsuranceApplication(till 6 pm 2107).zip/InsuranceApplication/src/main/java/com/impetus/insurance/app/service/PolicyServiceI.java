package com.impetus.insurance.app.service;

import java.util.List;

import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;

public interface PolicyServiceI {

	public void add(Policy object);

	public void remove(int policyId) throws InvalidPolicyIdException;

	public void edit(int id, Policy object) throws InvalidPolicyIdException;

	public List<Policy> viewAll();
	
	public Policy viewById(int id) throws InvalidPolicyIdException;
	
	
}
