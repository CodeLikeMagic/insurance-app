package com.impetus.insurance.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.service.NomineeServiceI;

@Component
public class NomineeService implements NomineeServiceI{

	@Autowired
	NomineeRepository nomineeRepo;

	@Override
	public boolean add(Nominee object) {
		// TODO Auto-generated method stub
		System.out.println(object.toString());
		nomineeRepo.save(object);
		return true;
	}

	@Override
	public void remove(int Id) {
		// TODO Auto-generated method stub
		nomineeRepo.deleteById(Id);
	}

	@Override
	public Nominee findByAadhar(long aNo) {
		// TODO Auto-generated method stub
		return nomineeRepo.findByAadharNo(aNo);
	}

}
