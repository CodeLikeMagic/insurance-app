package com.impetus.insurance.app.entity;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the User.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "user")
public class User {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	/**
	 * string value for firstName
	 */
	@NotNull
	@Column(name = "first_name")
	private String firstName;

	/**
	 * string value for lastName
	 */
	@NotNull
	@Column(name = "last_name")
	private String lastName;

	/**
	 * string value for email
	 */
	@NotNull
	@Column(name = "email_id")
	private String email;
	@NotNull

	/**
	 * long value for phone
	 */
	@Column(name = "phone")
	private long phone;

	/**
	 * string value for password
	 */
	@NotNull
	@Column(name = "password")
	private String password;

	/**
	 * string value for gender
	 */
	@NotNull
	@Column(name = "gender")
	String gender;

	/**
	 * Date value for dob
	 */
	@NotNull
	@Column(name = "dob")
	Date dob;

	/**
	 * int value for age
	 */
	@Column(name = "age")
	int age;

	/**
	 * long value for pincode
	 */
	@NotNull
	@Column(name = "pincode")
	long pincode;

	/**
	 * string value for city
	 */
	@NotNull
	@Column(name = "city")
	String city;

	/**
	 * string value for income
	 */
	@NotNull
	@Column(name = "income")
	String income;

	/**
	 * string value for education
	 */
	@NotNull
	@Column(name = "education")
	String education;

	/**
	 * string value for occupation
	 */
	@NotNull
	@Column(name = "occupation")
	String occupation;

	/**
	 * string value for nationality
	 */
	@NotNull
	@Column(name = "nationality")
	String nationality;

	/**
	 * bool value for smoker
	 */
	@NotNull
	@Column(name = "smoker", columnDefinition = "boolean default false")
	Boolean isSmoker;

	/**
	 * Default Constructor
	 */
	public User() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param phone
	 * @param password
	 * @param gender
	 * @param dob
	 * @param age
	 * @param pincode
	 * @param city
	 * @param income
	 * @param education
	 * @param occupation
	 * @param nationality
	 * @param isSmoker
	 */
	public User(int id, @NotNull String firstName, @NotNull String lastName, @NotNull String email, @NotNull long phone,
			@NotNull String password, @NotNull String gender, @NotNull Date dob, int age, @NotNull long pincode,
			@NotNull String city, @NotNull String income, @NotNull String education, @NotNull String occupation,
			@NotNull String nationality, @NotNull Boolean isSmoker) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.password = password;
		this.gender = gender;
		this.dob = dob;
		this.age = age;
		this.pincode = pincode;
		this.city = city;
		this.income = income;
		this.education = education;
		this.occupation = occupation;
		this.nationality = nationality;
		this.isSmoker = isSmoker;
	}

	
	/**This method calculates age from dob
	 * @param birthDate
	 * @return age
	 */
	public static int calculateAgeWithJava7(Date birthDate) {

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String bd = simpleDateFormat.format(birthDate);

		LocalDate dob = LocalDate.parse(bd);
		LocalDate curD = LocalDate.now();

		return Period.between(dob, curD).getYears(); // age
	}

}
