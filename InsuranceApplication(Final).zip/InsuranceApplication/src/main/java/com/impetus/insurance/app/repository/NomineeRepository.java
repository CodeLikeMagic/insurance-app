package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.Nominee;

@Repository
public interface NomineeRepository extends CrudRepository<Nominee, Integer>{
	Nominee findByAadharNo(long aadharNo);
}
