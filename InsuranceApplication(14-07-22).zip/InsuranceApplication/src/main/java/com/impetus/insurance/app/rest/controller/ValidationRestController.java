package com.impetus.insurance.app.rest.controller;

import javax.validation.Valid;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.dto.RegisteredUserDto;
import com.impetus.insurance.app.service.impl.RegisteredUserService;

@RestController
public class ValidationRestController {

	@Autowired
	RegisteredUserService registeredUserService;

	@PostMapping("user/login")
	public ResponseEntity<HttpStatus> userLogin(@RequestBody @Valid RegisteredUserDto object) throws InvalidCredentialsException{
		registeredUserService.validateLogin(object);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

	@PostMapping("user/signup")
	public ResponseEntity<HttpStatus> userSignUp(@RequestBody @Valid RegisteredUserDto object) {
		registeredUserService.createNewAccount(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
