package com.impetus.insurance.app.service;

import java.util.List;

import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;

/**
 * This interface implements PolicyService Interface,it declares the methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface PolicyServiceI {

	/**
	 * This method add new Policy object
	 * 
	 * @param object inputs Policy type object
	 */
	public void add(Policy object);

	/**
	 * This methods removes policy with a given policyId only if its not purchased
	 * else throws InvalidPolicyIdException
	 * 
	 * @param policyId
	 * @throws InvalidPolicyIdException
	 */
	public void remove(int policyId) throws InvalidPolicyIdException;

	/**
	 * This method updates the given policy object with given policyId
	 * 
	 * @param id
	 * @param object
	 * @throws InvalidPolicyIdException
	 */
	public void edit(int id, Policy object) throws InvalidPolicyIdException;

	/**
	 * This method returns all the existing policies.
	 * 
	 * @return List of Policy
	 */
	public List<Policy> viewAll();

	/**
	 * This method returns policy object with a given policyId if exists else throws
	 * InvalidPolicyIdException
	 * 
	 * @param id
	 * @return Policy object
	 * @throws InvalidPolicyIdException
	 */
	public Policy viewById(int id) throws InvalidPolicyIdException;

}
