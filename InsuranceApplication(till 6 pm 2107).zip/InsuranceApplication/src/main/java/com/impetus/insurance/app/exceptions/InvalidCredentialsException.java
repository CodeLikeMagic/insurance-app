package com.impetus.insurance.app.exceptions;

public class InvalidCredentialsException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//serializing an object //for object transfer it helps
	//marker interface
	public InvalidCredentialsException(String s)
	{
		super(s);
	}
}