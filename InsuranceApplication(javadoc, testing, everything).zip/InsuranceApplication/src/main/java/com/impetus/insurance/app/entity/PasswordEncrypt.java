package com.impetus.insurance.app.entity;


/**This class implements logic for encrypting password
 * @author deeksha.patidar
 *
 */
public class PasswordEncrypt {

	/**This method encrypts the input password
	 * @param orignal
	 * @return Encrypted password
	 */
	public static String EncryptPass(String orignal) {
		String encryptedPass = new String();

		StringBuffer temp = new StringBuffer();

		char ch[] = orignal.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			String hexString = Integer.toHexString(ch[i]);
			temp.append(hexString);
		}
		encryptedPass = temp.toString();
		return encryptedPass;
	}
}
